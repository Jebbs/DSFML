#ifndef DSFML_SOUNDBUFFERSTRUCT_H
#define DSFML_SOUNDBBUFFERSTRUCT_H

#include <SFML/Audio/SoundBuffer.hpp>

struct sfSoundBuffer
{
	sf::SoundBuffer This;
};


#endif //DSFML_SOUNDSTRUCT_H